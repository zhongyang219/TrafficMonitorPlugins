﻿#include "pch.h"
#include "BatteryItem.h"
#include "DataManager.h"

const wchar_t* CBatteryItem::GetItemName() const
{
    return g_data.StringRes(IDS_BATTERY);
}

const wchar_t* CBatteryItem::GetItemId() const
{
    return L"b5R30ITQ";
}

const wchar_t* CBatteryItem::GetItemLableText() const
{
    return L"";
}

const wchar_t* CBatteryItem::GetItemValueText() const
{
    return L"";
}

const wchar_t* CBatteryItem::GetItemValueSampleText() const
{
    return L"";
}

bool CBatteryItem::IsCustomDraw() const
{
    return true;
}

int CBatteryItem::GetItemWidth() const
{
    return 60;
}

void CBatteryItem::DrawItem(void* hDC, int x, int y, int w, int h, bool dark_mode)
{
    //绘图句柄
    CDC* pDC = CDC::FromHandle((HDC)hDC);
    //矩形区域
    CRect rect(CPoint(x, y), CSize(w, h));
    //TODO: 在此添加绘图代码
}
